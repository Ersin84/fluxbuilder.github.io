self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,H,J,P,W,D,S,R={uw:function uw(d,e,f){this.d=d
this.e=e
this.a=f},aTr:function aTr(d){var _=this
_.d=null
_.e=1
_.a=null
_.b=d
_.c=null},cxW:function cxW(d){this.a=d},cxV:function cxV(d){this.a=d},cxU:function cxU(d){this.a=d},cxT:function cxT(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g}},T,Q={
b7X:function(d,e){var x=null,w=M.r(x,x,C.c,x,x,x,x,x,x,x,x,x,x,x)
return new Q.ZG(d,e,w,x)},
d8P:function(d){if(!$.cIJ.au(0,d))$.cIJ.k(0,d,J.FX(d.$0(),new Q.b7Y(d),y.H))
return $.cIJ.h(0,d)},
ZG:function ZG(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
b7Y:function b7Y(d){this.a=d},
aJ7:function aJ7(d){var _=this
_.a=_.e=_.d=null
_.b=d
_.c=null},
bXQ:function bXQ(d){this.a=d},
bXO:function bXO(d){this.a=d},
qC:function(d){var x,w
try{if(d==null||J.F(d).length===0)return 0
x=H.q1(J.F(d))
return x}catch(w){H.D(w)
return 0}},
doR:function(d){var x=new Q.SU(null,null,null),w=J.G(d),v=w.h(d,"value")
x.a=v==null?"":v
v=w.h(d,"type")
x.b=v==null?"":v
w=w.h(d,"tag")
x.c=w==null?"":w
return x},
xd:function xd(d){this.b=d},
AB:function AB(d){this.b=d},
mT:function mT(d,e,f){this.a=d
this.b=e
this.c=f},
bHI:function bHI(){},
bHJ:function bHJ(){},
qg:function qg(){var _=this
_.f=_.e=_.d=_.c=_.b=_.a=null},
bHG:function bHG(){},
SU:function SU(d,e,f){this.a=d
this.b=e
this.c=f},
KX:function KX(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
a7Z:function a7Z(d,e,f){this.a=d
this.b=e
this.c=f},
SV:function SV(d,e){this.a=d
this.b=e}},G,Y,Z,X,E={
dau:function(d){var x,w,v,u,t
try{x=J.fO(d,new E.bfT(),y.V).eI(0)
return x}catch(u){w=H.D(u)
v=H.aH(u)
N.X(w,null)
N.X(v,null)
t=H.c([],y.m)
return t}},
bfT:function bfT(){}},N={aCj:function aCj(d,e,f,g,h,i,j,k,l,m,n,o,p){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.x=i
_.y=j
_.z=k
_.Q=l
_.ch=m
_.cx=n
_.cy=o
_.a=p}},K,B,A={
d7e:function(d,e,f,g){return new A.Yt(e,d,g,f,null)},
Yt:function Yt(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.f=f
_.r=g
_.a=h},
b4B:function b4B(d,e){this.a=d
this.b=e}},O,M,V={
cIf:function(d){var x=new V.NM(),w=J.G(d),v=w.h(d,"originalColor")
x.a=v==null?!1:v
v=w.h(d,"title")
x.b=v==null?w.h(d,"description"):v
x.d=w.h(d,"name")
x.y=w.h(d,"showText")
v=w.h(d,"keepDefaultTitle")
x.e=v==null?!1:v
v=w.h(d,"colors")
x.f=E.dau(v==null?[C.d.j(268435455)]:v)
x.r=w.h(d,"image")
x.x=w.h(d,"tag")
v=w.h(d,"category")
x.z=v==null?"":v
x.ch=w.h(d,"data")
x.Q=new E.ea(E.eK(w.h(d,"backgroundColor"))>>>0)
x.cx=d
return x},
NM:function NM(){var _=this
_.d=_.b=_.a=null
_.e=!1
_.x=_.r=_.f=null
_.y=!1
_.cx=_.ch=_.Q=_.z=null},
b4D:function b4D(){}},U,L,F
a.setFunctionNamesIfNecessary([R,Q,E,N,A,V])
C=c[0]
H=c[1]
J=c[2]
P=c[3]
W=c[4]
D=c[5]
S=c[6]
R=a.updateHolder(c[7],R)
T=c[8]
Q=a.updateHolder(c[9],Q)
G=c[10]
Y=c[11]
Z=c[12]
X=c[13]
E=a.updateHolder(c[14],E)
N=a.updateHolder(c[15],N)
K=c[16]
B=c[17]
A=a.updateHolder(c[18],A)
O=c[19]
M=c[20]
V=a.updateHolder(c[21],V)
U=c[22]
L=c[23]
F=c[24]
A.Yt.prototype={
n:function(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j=this,i=null
e.D(y.w).toString
x=j.f/3
w=Y.w(e,!0,y.Q).c
v=j.c
u=J.F(v.z)
t=w.h(0,u)!=null?w.h(0,u).c:""
s=w.h(0,u)!=null?w.h(0,u).d:""
r=w.h(0,u)!=null?w.h(0,u).f:""
q=v.r
if(q!=null)p=C.f.C(q,"http")?U.hl(q,i,i,i,C.cB,i,i,i):U.eq(q,C.p,i,i,C.cB,i,i,i)
else p=i
q=C.iu.h(0,"grey")
q.toString
o=new Y.bp(new E.ea(E.eK("5F"+q)>>>0),0.5,C.M)
q=H.c([],y.E)
n=j.d
if(n!=null){m=n.a
l=K.j(e).x.a
q.push(new O.ck(0,P.Q(C.e.L(255*n.b),l>>>16&255,l>>>8&255,l&255),new P.v(n.d,n.e),m))}n=j.r
if(n==null)n=140
m=p==null?X.er(C.af,!1,i,!1,!0,!1,0,C.lV,s,i):p
l=y.p
m=H.c([T.a3(M.r(i,m,C.c,i,i,C.abi,i,x*0.45,i,i,i,i,i,x),2)],l)
if(v.y===!0)m.push(C.dD)
if(v.y===!0){v=v.d
if(v==null){t.toString
v=t}v=L.u(v,i,i,1,C.az,i,i,i,C.vz,i,i,i)
k=L.A(e,C.k,y.t)
k.toString
k=k.bTc(H.f(r))
m.push(T.a3(M.r(i,T.M(H.c([C.d8,v,C.b2,L.u(k,i,i,i,i,i,i,i,C.a6Q,i,i,i)],l),C.t,i,C.i,C.h,i,C.l),C.c,i,i,i,i,i,i,i,C.et,i,i,i),1))}return new T.S(C.am6,D.aj(i,M.r(i,T.M(m,C.t,i,C.i,C.h,i,C.l),C.c,i,i,new S.W(i,i,new F.bx(o,o,o,o),C.m7,q,i,i,C.o),i,n,i,C.et,i,i,i,x),C.n,!1,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,new A.b4B(j,e),i,i,i,i,i,i,i,i),i)},
gc_:function(){return this.c}}
V.NM.prototype={
aa:function(){var x=this,w=P.L(y.N,y.z)
w.k(0,"originalColor",x.a)
w.k(0,"title",x.b)
w.k(0,"keepDefaultTitle",x.e)
w.k(0,"colors",x.f)
w.k(0,"image",x.r)
w.k(0,"tag",x.x)
w.k(0,"category",x.z)
return w},
gbxS:function(){var x,w=this.f
w.toString
x=H.ap(w).i("ai<1,N>")
return P.ac(new H.ai(w,new V.b4D(),x),!0,x.i("bt.E"))},
gaiv:function(){var x,w,v=this
if(J.F(v.Q)==="Color(0xffffffff)"||v.Q==null){x=v.f
if(x.length===1){x=C.b.ga2(x)
w=J.aC(x)
x=P.Q(30,w.gl(x)>>>16&255,w.gl(x)>>>8&255,w.gl(x)&255)}else x=null
return x}x=v.Q.a
return P.Q(30,x>>>16&255,x>>>8&255,x&255)},
gcz:function(d){return this.b},
gic:function(){return null},
gah:function(d){return this.d},
gjG:function(){return this.z},
gbv:function(d){return this.ch}}
Q.ZG.prototype={
w:function(){return new Q.aJ7(C.m)}}
Q.aJ7.prototype={
G:function(){var x=this
if($.cRw.C(0,x.a.c))x.auw()
else Q.d8P(x.a.c).a8(0,new Q.bXQ(x),y.H)
x.S()},
auw:function(){this.p(new Q.bXO(this))},
n:function(d,e){var x,w=this
if(!J.B(w.e,w.a.d)&&w.e!=null){x=w.a.d
w.e=x
w.d=x.$0()}x=w.d
return x==null?w.a.e:x}}
Q.xd.prototype={
j:function(d){return this.b}}
Q.AB.prototype={
j:function(d){return this.b}}
Q.mT.prototype={
amy:function(a2){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l="contents",k="typography",j="animation",i="padding",h="bottom",g="left",f="right",e="margin",d="paddingContent",a0=J.G(a2),a1=a0.h(a2,"layout")
n.a=a1==null?H.hi(""):a1
a1=a0.h(a2,"urlImage")
n.b=a1==null?"":a1
n.c=H.c([],y.F)
if(a0.h(a2,l)!=null&&J.bg(a0.h(a2,l)))for(a0=J.a7(a0.h(a2,l));a0.t();){x=a0.gA(a0)
a1=n.c
a1.toString
w=new Q.qg()
v=J.G(x)
u=v.h(x,"title")
w.a=u==null?"":u
if(v.h(x,"link")!=null){u=new Q.SU(m,m,m)
u.b3H(v.h(x,"link"))
w.c=u}if(v.h(x,k)!=null){u=v.h(x,k)
t=new Q.KX(m,m,m,m,m)
s=J.G(u)
r=s.h(u,"font")
t.a=r==null?"Roboto":r
t.b=Q.qC(s.h(u,"fontSize"))
r=s.h(u,"fontStyle")
t.c=r==null?"":r
r=s.h(u,"align")
t.d=r==null?"":r
u=s.h(u,"transform")
t.e=u==null?"":u
w.d=t}if(v.h(x,j)!=null){u=v.h(x,j)
t=new Q.a7Z(m,m,m)
s=J.G(u)
r=s.h(u,"type")
t.a=r==null?"":r
r=s.h(u,"milliseconds")
t.b=r==null?300:r
u=s.h(u,"delaySecond")
t.c=u==null?0:u
w.e=t}if(v.h(x,"spacing")!=null){u=v.h(x,"spacing")
t=new Q.SV(m,m)
s=J.G(u)
if(s.h(u,i)!=null){r=Q.qC(J.d(s.h(u,i),"top"))
if(r==null)r=0
q=Q.qC(J.d(s.h(u,i),h))
if(q==null)q=0
p=Q.qC(J.d(s.h(u,i),g))
if(p==null)p=0
o=Q.qC(J.d(s.h(u,i),f))
t.a=new V.Y(p,r,o==null?0:o,q)}if(s.h(u,e)!=null){r=Q.qC(J.d(s.h(u,e),"top"))
if(r==null)r=0
q=Q.qC(J.d(s.h(u,e),h))
if(q==null)q=0
p=Q.qC(J.d(s.h(u,e),g))
if(p==null)p=0
u=Q.qC(J.d(s.h(u,e),f))
t.b=new V.Y(p,r,u==null?0:u,q)}w.f=t}if(v.h(x,d)!=null){u=Q.qC(J.d(v.h(x,d),"top"))
if(u==null)u=0
t=Q.qC(J.d(v.h(x,d),h))
if(t==null)t=0
s=Q.qC(J.d(v.h(x,d),g))
if(s==null)s=0
v=Q.qC(J.d(v.h(x,d),f))
w.b=new V.Y(s,u,v==null?0:v,t)}C.b.v(a1,w)}},
It:function(d){var x,w=this.c
w.toString
x=H.ap(w).i("ai<1,qg>")
x=P.ac(new H.ai(w,new Q.bHI(),x),!0,x.i("bt.E"))
return new Q.mT(this.a,this.b,x)},
aa:function(){var x,w,v,u=this.a
if(u==null)u=""
x=this.b
if(x==null)x=""
w=this.c
if(w!=null&&w.length!==0){w.toString
v=H.ap(w).i("ai<1,a_<t,@>>")
v=P.ac(new H.ai(w,new Q.bHJ(),v),!0,v.i("bt.E"))
w=v}else w=[]
return P.z(["layout",u,"urlImage",x,"contents",w],y.N,y.z)},
gfW:function(d){return this.a}}
Q.qg.prototype={
Lk:function(){var x,w=this,v=w.d
if(v!=null){x=v.e
x=x==null?null:x.length===0
x=x!==!1}else x=!0
if(x)return w.a
v=v.e
x=w.a
switch(v){case"lower":return x.toLowerCase()
case"uper":x.toString
return w.bT7(x)
case"full":return x.toUpperCase()
default:return x}},
bT7:function(d){if(d.length<=1)return d.toUpperCase()
return new H.ai(H.c(d.toLowerCase().split(" "),y.s),new Q.bHG(),y.e).cS(0," ")},
aa:function(){var x=this,w=y.z,v=P.L(w,w),u=x.b
if(u!=null)v=P.z(["top",u.b,"bottom",u.d,"left",u.a,"right",u.c],w,w)
return P.z(["title",x.a,"link",x.c.aa(),"typography",x.d.aa(),"animation",x.e.aa(),"spacing",x.f.aa(),"paddingContent",v],y.N,w)},
gcz:function(d){return this.a}}
Q.SU.prototype={
gbK:function(d){var x=this.a
x=x==null?null:x.length!==0
if(x===!0){x=this.b
x=x==null?null:x.length!==0
x=x===!0}else x=!1
return x},
b3H:function(d){var x=J.G(d),w=x.h(d,"value")
this.a=w==null?"":w
w=x.h(d,"type")
this.b=w==null?"":w
x=x.h(d,"tag")
this.c=x==null?"":x},
aa:function(){var x,w,v=this.a
if(v==null)v=""
x=this.b
if(x==null)x=""
w=this.c
return P.z(["value",v,"type",x,"tag",w==null?"":w],y.N,y.z)},
gl:function(d){return this.a}}
Q.KX.prototype={
aa:function(){var x,w,v,u,t=this,s=t.a
if(s==null)s="Roboto"
x=t.b
if(x==null)x=15
w=t.c
if(w==null)w=""
v=t.d
if(v==null)v=""
u=t.e
return P.z(["font",s,"fontSize",x,"fontStyle",w,"align",v,"transform",u==null?"":u],y.N,y.z)},
acj:function(){switch(this.d){case"center":return C.Z
case"left":return C.cI
case"right":return C.dl
case"justify":return C.fZ
default:return C.cI}},
bBB:function(){switch(this.e){case"lower":return C.DP
case"uper":return C.DO
case"full":return C.a7u
default:return C.a7v}},
aOB:function(){switch(this.c){case"underline":return C.DJ
case"bold":return C.DK
case"italic":return C.DL
case"line":return C.DM
default:return C.DN}}}
Q.a7Z.prototype={
aa:function(){var x,w,v=this.a
if(v==null)v=""
x=this.b
if(x==null)x=300
w=this.c
return P.z(["type",v,"milliseconds",x,"delaySecond",w==null?0:w],y.N,y.z)}}
Q.SV.prototype={
aa:function(){var x,w=y.z,v=P.L(w,w),u=this.a
if(u!=null)v=P.z(["top",u.b,"bottom",u.d,"left",u.a,"right",u.c],w,w)
x=P.L(w,w)
u=this.b
return P.z(["padding",v,"margin",u!=null?P.z(["top",u.b,"bottom",u.d,"left",u.a,"right",u.c],w,w):x],y.N,w)}}
R.uw.prototype={
w:function(){return new R.aTr(C.m)}}
R.aTr.prototype={
G:function(){$.ae.ch$.push(new R.cxW(this))
this.S()},
n:function(d,e){return new A.ce(new R.cxU(this),null)}}
N.aCj.prototype={}
var z=a.updateTypes(["qg(qg)","a_<t,@>(qg)"])
A.b4B.prototype={
$0:function(){var x=null
return A.rr(x,x,this.a.c.aa(),this.b,C.B,x,!1,x)},
$S:0}
V.b4D.prototype={
$1:function(d){var x=d.a
return P.Q(30,x>>>16&255,x>>>8&255,x&255)},
$S:1428}
E.bfT.prototype={
$1:function(d){return new E.ea(E.eK(H.cu(d))>>>0)},
$S:1429}
Q.b7Y.prototype={
$1:function(d){$.cRw.v(0,this.a)},
$S:2}
Q.bXQ.prototype={
$1:function(d){return this.a.auw()},
$S:4}
Q.bXO.prototype={
$0:function(){var x=this.a,w=x.a.d
x.e=w
x.d=w.$0()},
$S:0}
Q.bHI.prototype={
$1:function(d){var x=new Q.qg(),w=d.a
x.a=w==null?"Text":w
w=d.b
x.b=w==null?C.F:w
w=d.c
x.c=w==null?new Q.SU("","",""):w
w=d.e
x.e=w==null?new Q.a7Z("",300,0):w
w=d.f
x.f=w==null?new Q.SV(C.F,C.F):w
w=d.d
x.d=w==null?new Q.KX("Roboto",15,"normal","center","nomarl"):w
return x},
$S:z+0}
Q.bHJ.prototype={
$1:function(d){return d.aa()},
$S:z+1}
Q.bHG.prototype={
$1:function(d){return C.f.ab(d,0,1).toUpperCase()+C.f.cB(d,1)},
$S:28}
R.cxW.prototype={
$1:function(d){var x=this.a
x.p(new R.cxV(x))},
$S:7}
R.cxV.prototype={
$0:function(){this.a.e=1},
$S:0}
R.cxU.prototype={
$2:function(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h=null,g=this.a,f=g.a
f.toString
x=e.b
g.d=x
w=f.d
f=w==null
if(f)v=h
else{v=w.b
if(v==null)v=h
else if(v.length!==0)v=C.f.C(v,"http")||C.f.C(v,"https")
else v=!1}if(v===!0){v=w.b
v.toString
v=U.a_B(v,C.p,!0,h,!0,!1,C.af,h,h,C.dPQ,h,C.mO,h,h)}else v=C.dEU
if(f)u=h
else{f=w.c
f=f==null?h:f.length
u=f}if(u==null)u=0
t=J.bP(u,y.l)
for(f=y.O,s=0;s<u;++s){r=w.c[s].b
r=r==null?r:h
q=r==null?C.F:r
p="story_item"+s
o=w.c[s].f
n=o.a
o=o.b
m=g.e
l="keyTextOfCardStory_"+s
k=g.a.d.c[s]
j="storyText_"+s
i=k.Lk()
i.toString
t[s]=new T.S(q,M.r(h,new G.By(D.aj(h,new N.aCj(i,h,h,h,k.d.acj(),h,h,h,h,h,h,h,new D.b2(j,f)),C.n,!1,new D.b2(l,f),h,h,h,h,h,h,h,h,h,h,h,h,h,h,new R.cxT(g,w,s,d),h,h,h,h,h,h,h,h),m,!1,C.H,C.qe,h,h),C.c,h,h,h,h,h,new D.b2(p,f),o,n,h,h,h),h)}return new T.aM(x,e.d,T.aZ(C.C,H.c([v,E.bu(new T.S(C.ce,T.M(t,C.j,h,C.i,C.h,h,C.l),h),h,C.n,h,C.c3,C.r)],y.p),C.y,C.fW,h,h),h)},
$S:456}
R.cxT.prototype={
$0:function(){var x,w,v,u,t=this,s=null,r=y.z,q=P.L(r,r)
r=t.b
x=t.c
w=r.c[x].c
w=w==null?s:w.gbK(w)
if(w===!0){w=r.c[x].c
v=w.b
w=w.a
if(v==="category"){q.k(0,"category",w)
r=r.c[x].c.c
x=r==null?s:r.length!==0
if(x===!0){r.toString
q.k(0,"tag",P.bY(r,s))}}else q.k(0,v,w)}r=t.a.a.e
if(r!=null)r.$1(q)
if(q.h(0,"tab")!=null){u=K.cUo(t.d)
r=u!=null&&u.vF()}else r=!1
if(r)K.a4(t.d,!1).bh(0,s)},
$S:0};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(A.Yt,N.Z)
w(H.fQ,[A.b4B,V.b4D,E.bfT,Q.b7Y,Q.bXQ,Q.bXO,Q.bHI,Q.bHJ,Q.bHG,R.cxW,R.cxV,R.cxU,R.cxT])
w(P.a5,[V.NM,Q.xd,Q.AB,Q.mT,Q.qg,Q.SU,Q.KX,Q.a7Z,Q.SV])
w(N.J,[Q.ZG,R.uw])
w(N.K,[Q.aJ7,R.aTr])
x(N.aCj,L.at)})()
H.ew(b.typeUniverse,JSON.parse('{"Yt":{"Z":[],"h":[]},"ZG":{"J":[],"h":[]},"aJ7":{"K":["ZG"]},"uw":{"J":[],"h":[]},"aTr":{"K":["uw"]},"aCj":{"Z":[],"h":[]},"tK":{"Z":[],"h":[]},"y3":{"Z":[],"h":[]},"BT":{"Z":[],"h":[]},"BV":{"Z":[],"h":[]},"vD":{"Z":[],"h":[]}}'))
0
var y=(function rtii(){var x=H.a9
return{Q:x("hv"),V:x("ea"),E:x("E<ck>"),m:x("E<ea>"),F:x("E<qg>"),s:x("E<t>"),p:x("E<h>"),e:x("ai<t,t>"),w:x("hQ"),t:x("nX"),N:x("t"),O:x("b2<t>"),l:x("h"),z:x("@"),H:x("~")}})();(function constants(){C.aap=new K.cc(C.jD,C.jD,C.a1,C.a1)
C.abi=new S.W(null,null,null,C.aap,null,null,null,C.o)
C.HU=new V.Y(0,0,5,0)
C.am6=new V.Y(5,0,0,10)
C.dEU=new N.axO(C.GE,null)
C.DJ=new Q.xd("TypographyFontStyle.underline")
C.DK=new Q.xd("TypographyFontStyle.bold")
C.DL=new Q.xd("TypographyFontStyle.italic")
C.DM=new Q.xd("TypographyFontStyle.line")
C.DN=new Q.xd("TypographyFontStyle.none")
C.DO=new Q.AB("TypographyTransform.uper")
C.DP=new Q.AB("TypographyTransform.lower")
C.a7u=new Q.AB("TypographyTransform.full")
C.a7v=new Q.AB("TypographyTransform.normal")
C.dPQ=new D.b2("story_background",y.O)})();(function staticFields(){$.cIJ=P.L(H.a9("al<~>()"),H.a9("al<~>"))
$.cRw=P.aV(H.a9("al<~>()"))})()}
$__dart_deferred_initializers__["PfvkTFBSAOmfiyqEW6ceAHoEUnA="] = $__dart_deferred_initializers__.current
//# sourceMappingURL=main.dart.js_12.part.js.map
