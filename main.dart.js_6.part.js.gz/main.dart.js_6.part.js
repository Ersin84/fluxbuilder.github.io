self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,H,J,P,W,D={
MC:function(d,e){return D.dAB(d,e)},
dAB:function(d,e){var w=0,v=P.q(x.w),u,t=2,s,r=[],q,p,o
var $async$MC=P.m(function(f,g){if(f===1){s=g
w=t}while(true)switch(w){case 0:t=4
w=7
return P.k($.oq().Bz(d),$async$MC)
case 7:q=g
u=q
w=1
break
t=2
w=6
break
case 4:t=3
o=s
H.D(o)
w=8
return P.k($.oq().Bz(e),$async$MC)
case 8:q=g
u=q
w=1
break
w=6
break
case 3:w=2
break
case 6:case 1:return P.o(u,v)
case 2:return P.n(s,v)}})
return P.p($async$MC,v)},
bo4:function bo4(d,e){this.c=null
this.a=d
this.b=e}},S,R,T,Q,G,Y,Z,X,E={Pj:function Pj(){},bod:function bod(){}},N,K,B,A,O,M,V,U,L,F
a.setFunctionNamesIfNecessary([D,E])
C=c[0]
H=c[1]
J=c[2]
P=c[3]
W=c[4]
D=a.updateHolder(c[5],D)
S=c[6]
R=c[7]
T=c[8]
Q=c[9]
G=c[10]
Y=c[11]
Z=c[12]
X=c[13]
E=a.updateHolder(c[14],E)
N=c[15]
K=c[16]
B=c[17]
A=c[18]
O=c[19]
M=c[20]
V=c[21]
U=c[22]
L=c[23]
F=c[24]
E.Pj.prototype={
Tu:function(d){d.k(0,"isBuilder",!0)
$.aN().rY(d)}}
E.bod.prototype={}
D.bo4.prototype={
ad1:function(d){switch(this.c){case"fluxlisting":return T.Rm(d)
case"fluxnews":return N.mv(d)
default:return T.ayh(d)}},
bDR:function(d){var w,v,u
switch(this.c){case"fluxlisting":w=d
w=w
u=new R.ep()
u.amm(w)
return u
case"fluxnews":u=new R.ep()
u.amn(d)
return u
default:v=d
v=v
u=new R.ep()
u.a4h(v)
return u}},
f7:function(d){var w=0,v=P.q(x.i),u,t=this,s,r,q,p,o
var $async$f7=P.m(function(e,f){if(e===1)return P.n(f,v)
while(true)switch(w){case 0:N.X(y.c+H.f(t.c)+"/categories.json",null)
o=C.q
w=3
return P.k(D.MC("packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/categories.json","packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/categories.json"),$async$f7)
case 3:s=o.a7(0,f,null)
r=H.c([],x.a)
for(q=J.a7(s);q.t();){p=q.gA(q)
if(!J.B(J.d(p,"slug"),"uncategorized"))r.push(t.bDR(p))}u=r
w=1
break
case 1:return P.o(u,v)}})
return P.p($async$f7,v)},
ez:function(d,e,f){var w=0,v=P.q(x.q),u,t=this,s,r,q,p,o,n,m,l
var $async$ez=P.m(function(g,h){if(g===1)return P.n(h,v)
while(true)switch(w){case 0:n=H.c([],x.z)
N.X(y.c+H.f(t.c)+"/products.json",null)
m=J
l=C.q
w=3
return P.k(D.MC("packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json","packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json"),$async$ez)
case 3:s=m.a7(l.a7(0,h,null)),r=J.G(d)
case 4:if(!s.t()){w=5
break}q=s.gA(s)
p=t.ad1(q)
if(r.h(d,"category")!=null&&H.f(r.h(d,"category")).length!==0)p.sbzS(J.F(r.h(d,"category")))
o=J.G(q)
if(o.h(q,"store")!=null)if(J.d(o.h(q,"store"),"errors")!=null){n.push(p)
w=4
break}n.push(p)
w=4
break
case 5:u=n
w=1
break
case 1:return P.o(u,v)}})
return P.p($async$ez,v)},
w1:function(d,e){return this.ez(d,e,null)},
pW:function(d,e){var w=0,v=P.q(x.p),u,t=this,s,r,q,p
var $async$pW=P.m(function(f,g){if(f===1)return P.n(g,v)
while(true)switch(w){case 0:r=H.c([],x.C)
N.X(y.c+H.f(t.c)+"/products.json",null)
q=J
p=C.q
w=3
return P.k(D.MC("packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json","packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json"),$async$pW)
case 3:s=q.a7(p.a7(0,g,null))
case 4:if(!s.t()){w=5
break}r.push(t.ad1(s.gA(s)))
w=4
break
case 5:u=r
w=1
break
case 1:return P.o(u,v)}})
return P.p($async$pW,v)},
adT:function(d){return this.pW(d,null)},
dg:function(d,e,f,g,h,i,j,k,l,a0,a1,a2,a3,a4){var w=0,v=P.q(x.q),u,t=this,s,r,q,p,o,n,m
var $async$dg=P.m(function(a5,a6){if(a5===1)return P.n(a6,v)
while(true)switch(w){case 0:o=H.c([],x.z)
n=J
m=C.q
w=3
return P.k(D.MC("packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json","packages/core_builder/lib/example/mocks/"+H.f(t.c)+"/products.json"),$async$dg)
case 3:s=n.a7(m.a7(0,a6,null))
case 4:if(!s.t()){w=5
break}r=s.gA(s)
q=t.ad1(r)
p=J.G(r)
if(p.h(r,"store")!=null)if(J.d(p.h(r,"store"),"errors")!=null){o.push(q)
w=4
break}o.push(q)
w=4
break
case 5:u=o
w=1
break
case 1:return P.o(u,v)}})
return P.p($async$dg,v)},
yp:function(d,e,f,g,h,i,j,k){return this.dg(null,null,d,null,e,null,f,g,null,h,i,j,null,k)},
p1:function(d,e,f){return this.dg(null,null,d,null,e,null,null,null,null,null,null,f,null,null)},
yo:function(d,e,f,g,h,i,j){return this.dg(null,null,d,null,e,null,f,g,null,h,i,j,null,null)},
yn:function(d,e){return this.dg(null,null,d,null,null,null,null,null,null,null,null,e,null,null)},
w0:function(d,e,f,g){return this.dg(null,null,d,null,e,null,null,null,null,null,null,f,null,g)}}
var z=a.updateTypes([]);(function inheritance(){var w=a.inherit
w(E.bod,P.a5)
w(E.Pj,E.bod)
w(D.bo4,E.XE)})()
H.ew(b.typeUniverse,JSON.parse('{}'))
var y={c:"[load mock data] packages/core_builder/lib/example/mocks/"}
var x={C:H.a9("E<c2>"),a:H.a9("E<ep>"),z:H.a9("E<cI>"),i:H.a9("I<ep>"),q:H.a9("I<cI>"),w:H.a9("t"),p:H.a9("I<c2>?")}}
$__dart_deferred_initializers__["kfeTYqFuIA+rMK/wuFFA5vyoS3k="] = $__dart_deferred_initializers__.current
//# sourceMappingURL=main.dart.js_6.part.js.map
