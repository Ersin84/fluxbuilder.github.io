self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,H,J,P,W,D,S,R,T,Q,G,Y,Z,X,E,N,K,B={
cSs:function(d){var x,w,v,u,t=H.c([],y.k)
for(x=y.g,w=y.b,v=0;v<d.length;++v){u=P.bk(d[v],x,w)
if(J.d(d[v],"category")!=null)u.k(0,"key",B.dH(11+v))
u.k(0,"pos",100+v*100)
t.push(u)}return t},
cSt:function(d){var x=P.bk(d,y.g,y.b)
if(J.cg(d))return x
x.k(0,"isVertical",!0)
x.k(0,"key",B.dH(10))
return x}},A,O,M,V,U,L,F
a.setFunctionNamesIfNecessary([B])
C=c[0]
H=c[1]
J=c[2]
P=c[3]
W=c[4]
D=c[5]
S=c[6]
R=c[7]
T=c[8]
Q=c[9]
G=c[10]
Y=c[11]
Z=c[12]
X=c[13]
E=c[14]
N=c[15]
K=c[16]
B=a.updateHolder(c[17],B)
A=c[18]
O=c[19]
M=c[20]
V=c[21]
U=c[22]
L=c[23]
F=c[24]
var z=a.updateTypes([])
H.ew(b.typeUniverse,JSON.parse('{"Cc":{"J":[],"h":[]},"Cb":{"J":[],"h":[]},"Ce":{"J":[],"h":[]},"tx":{"J":[],"h":[]}}'))
0
var y={k:H.a9("E<a_<t,@>>"),g:H.a9("t"),b:H.a9("@")};(function constants(){C.a5r=new D.mb("ScreenValue.tabbar")})()}
$__dart_deferred_initializers__["K2KZN2lberVKuZ4fR8wzEW6p/b4="] = $__dart_deferred_initializers__.current
//# sourceMappingURL=main.dart.js_44.part.js.map
