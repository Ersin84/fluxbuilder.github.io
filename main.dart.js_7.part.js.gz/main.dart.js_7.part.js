self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,H,J,P,W,D,S,R={
dtJ:function(){return H.f2("design.1")},
ZK:function ZK(d){this.a=d},
aSW:function aSW(d){var _=this
_.a=_.d=null
_.b=d
_.c=null},
cuL:function cuL(d){this.a=d},
cuM:function cuM(d){this.a=d},
cuN:function cuN(d,e){this.a=d
this.b=e},
cuO:function cuO(){},
cuP:function cuP(){},
cuS:function cuS(){},
cuR:function cuR(d,e){this.a=d
this.b=e},
cuQ:function cuQ(d,e){this.a=d
this.b=e}},T,Q,G,Y,Z,X,E,N,K={
d70:function(d,e,a0){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j="TabBarConfig",i=null,h="VerticalLayout",g="SplashScreen",f=Y.w(a0,!1,y.k)
try{q=J.G(e)
x=q.h(e,"Setting")
w=q.h(e,"Drawer")
for(p=J.ed(J.ia(x)),o=p.length,n=0;n<p.length;p.length===o||(0,H.a0)(p),++n){v=p[n]
f.aLa(v,J.d(x,v))}if(J.d(x,j)==null)f.aLa(j,i)
N.X("--updated setting",i)
if(w!=null){for(p=J.ed(J.ia(w)),o=p.length,n=0;n<p.length;p.length===o||(0,H.a0)(p),++n){u=p[n]
f.bTN(u,J.d(w,u))}N.X("--update drawer",i)}f.S_(B.dad(P.by(q.h(e,"TabBar"),!0,y.P)))
N.X("--updated tabbar",i)
t=D.cV1(a0,e,!0)
f.KC(B.cSs(t))
N.X("--updated list horizontal widget",i)
p=q.h(e,"Background")
if(p==null){p=y.z
p=P.L(p,p)}o=y.N
m=y.z
s=P.bk(p,o,m)
p=f
p.a.y=s
p.fR()
N.X("--updated background",i)
if(q.h(e,h)!=null){p=f
l=P.bk(B.cSt(q.h(e,h)),o,m)
p.a.f=l
p.fR()
N.X(q.h(e,h),i)}else{p=f
p.a.f=P.L(o,m)
p.fR()}N.X("--updated vertical widget",i)
if(q.h(e,g)!=null){p=f
q=P.bk(q.h(e,g),o,m)
p.a.Q=P.bk(q,o,m)
p.fR()}else{q=f
q.a.Q=P.L(o,m)
q.fR()}N.X("--updated splash screen widget",i)}catch(k){r=H.D(k)
N.X(J.F(r),i)}}},B={
dad:function(d){var x,w,v,u,t=H.c([],y.t)
for(x=y.N,w=y.z,v=0;v<d.length;++v){u=P.bk(d[v],x,w)
u.k(0,"pos",100+v*100)
u.k(0,"key",B.dH(10))
t.push(u)}return t}},A,O,M,V,U,L={
cRB:function(d,e){return new L.Cd(d,e,null)},
Cd:function Cd(d,e,f){this.c=d
this.d=e
this.a=f},
aC7:function aC7(d,e){var _=this
_.d=null
_.ar$=d
_.a=null
_.b=e
_.c=null},
bHu:function bHu(d){this.a=d},
af4:function af4(){}},F
a.setFunctionNamesIfNecessary([R,K,B,L])
C=c[0]
H=c[1]
J=c[2]
P=c[3]
W=c[4]
D=c[5]
S=c[6]
R=a.updateHolder(c[7],R)
T=c[8]
Q=c[9]
G=c[10]
Y=c[11]
Z=c[12]
X=c[13]
E=c[14]
N=c[15]
K=a.updateHolder(c[16],K)
B=a.updateHolder(c[17],B)
A=c[18]
O=c[19]
M=c[20]
V=c[21]
U=c[22]
L=a.updateHolder(c[23],L)
F=c[24]
L.Cd.prototype={
w:function(){return new L.aC7(null,C.m)}}
L.aC7.prototype={
gev:function(){var x=this.d
return x==null?H.e(H.i("tabController")):x},
G:function(){var x=this
x.S()
x.d=U.bKA(0,5,x)
x.bID()},
yG:function(){var x=0,w=P.q(y.H),v=[],u=this,t,s,r,q,p,o
var $async$yG=P.m(function(d,e){if(d===1)return P.n(e,w)
while(true)switch(x){case 0:try{q=u.c
q.toString
p=y.k
Y.w(q,!1,p).bJP(u.a.c)
t=null
t=P.bk(u.a.d,y.N,y.z)
q=u.c
q.toString
p=Y.w(q,!1,p)
q=y.P.a(t)
p.a.d=q
p.fR()
$.pg().rY(t)
new E.Pj().Tu(t)}catch(n){s=H.D(n)
r=H.aH(n)
N.X(s,null)
N.X(r,null)}return P.o(null,w)}})
return P.p($async$yG,w)},
aeE:function(){var x=0,w=P.q(y.H),v=[],u=this,t,s,r,q
var $async$aeE=P.m(function(d,e){if(d===1)return P.n(e,w)
while(true)switch(x){case 0:try{r=u.c
r.toString
K.d70(!0,Y.w(r,!1,y.D).ajh(),r)
r=$.ez;(r==null?$.ez=new U.iX():r).a=null
r=u.c
r.toString
r=Y.w(r,!1,y.k)
r.c=!1
r.fR()}catch(p){t=H.D(p)
s=H.aH(p)
N.X(t,null)
N.X(s,null)}return P.o(null,w)}})
return P.p($async$aeE,w)},
bID:function(){var x,w,v
try{P.cR(C.B,new L.bHu(this),y.a)}catch(v){x=H.D(v)
w=H.aH(v)
N.X(x,null)
N.X(w,null)}},
m:function(d){this.gev().m(0)
this.b_v(0)},
n:function(d,e){var x,w,v=H.c([],y.h)
for(x=$.eN().gaGs(),w=0;w<4;++w)v.push(x[w])
return Y.awh(null,C.ajp,null,v)}}
L.af4.prototype={
m:function(d){this.a1(0)},
a3:function(){var x,w=this.ar$
if(w!=null){x=this.c
x.toString
w.sbf(0,!U.bl(x))}this.az()}}
R.ZK.prototype={
w:function(){return new R.aSW(C.m)}}
R.aSW.prototype={
bdm:function(d,e){var x,w,v,u,t=this,s=null
switch(d){case C.dFG:case C.dFB:case C.v6:return Q.mz(R.aYa(),new R.cuL(t))
case C.dFH:break
case C.a5s:if(t.d.length===0)return Q.mz(R.aYa(),new R.cuM(t))
x=H.c([],y.s)
for(w=t.d,v=w.length,u=0;u<w.length;w.length===v||(0,H.a0)(w),++u)x.push(J.d(w[u],"layout"))
return Q.mz(R.aYa(),new R.cuN(t,e))
case C.dFC:break
case C.a5o:return Q.mz(R.aYa(),new R.cuO())
case C.a5p:break
case C.dFE:break
case C.dFF:break
case C.a5q:break
case C.a5r:return Q.mz(R.aYa(),new R.cuP())
case C.dFI:case C.a5t:case C.dFD:break}return M.r(s,s,C.c,s,s,s,s,s,s,s,s,s,s,s)},
bU9:function(){var x=this.c
x.toString
x=Y.w(x,!0,y.k).a.r
this.d=x
C.b.fw(x,new R.cuS())},
n:function(d,e){var x,w,v,u,t=null,s=Y.w(e,!0,y.v)
this.bU9()
x=y.w
w=e.D(x).f
x=e.D(x).f
v=K.j(e)
u=K.j(e)
return M.r(t,K.awr(t,t,C.nl,K.ais(),new R.cuR(this,s),t,!1,t),C.c,t,t,new S.W(u.rx,t,new F.bx(C.R,C.R,C.R,new Y.bp(v.x1,0.5,C.M)),t,t,t,t,C.o),t,x.a.b,t,t,t,t,t,w.a.a*0.32)}}
var z=a.updateTypes(["Cc()","tx()","Cb()","Ce()","al<@>()"])
L.bHu.prototype={
$0:function(){var x=0,w=P.q(y.a),v=this,u,t,s,r,q
var $async$$0=P.m(function(d,e){if(d===1)return P.n(e,w)
while(true)switch(x){case 0:r=v.a
q=r.c
q.toString
u=Y.w(q,!1,y.v)
q=r.c
q.toString
t=Y.w(q,!1,y.S)
q=r.c
q.toString
s=y.k
q=Y.w(q,!1,s)
q.c=!0
q.fR()
r.a.toString
q=r.c
q.toString
Y.w(q,!1,s)
P.bk(r.a.d,y.N,y.z)
x=2
return P.k(t.n8(),$async$$0)
case 2:x=3
return P.k(r.yG(),$async$$0)
case 3:u.bFy(r.gev())
q=u
q.a=C.v6
q.I()
x=4
return P.k(r.aeE(),$async$$0)
case 4:r=$.eN()
r.cx.Li(0)
x=5
return P.k(r.a1H(),$async$$0)
case 5:return P.o(null,w)}})
return P.p($async$$0,w)},
$S:37}
R.cuL.prototype={
$0:function(){var x,w,v,u,t
H.dI("design.1")
x=this.a
w=x.c
w.toString
v=Y.w(w,!1,y.v).b
u=x.c
u.toString
t=y.k
u=Y.w(u,!1,t).gajT()
u.toString
x=x.c
x.toString
return Y.cRA(new D.b2(B.aDG(u+H.f(Y.w(x,!1,t).gajU())),y.O),w,v)},
$C:"$0",
$R:0,
$S:z+0}
R.cuM.prototype={
$0:function(){var x,w,v,u,t
H.dI("design.1")
x=this.a
w=x.c
w.toString
v=Y.w(w,!1,y.v).b
u=x.c
u.toString
t=y.k
u=Y.w(u,!1,t).gajT()
u.toString
x=x.c
x.toString
return Y.cRA(new D.b2(B.aDG(u+H.f(Y.w(x,!1,t).gajU())),y.O),w,v)},
$C:"$0",
$R:0,
$S:z+0}
R.cuN.prototype={
$0:function(){var x,w,v
H.dI("design.1")
x=this.a
w=x.c
w.toString
v=this.b
return Z.d8S(new D.b2("tabbar_"+Y.w(w,!1,y.v).b,y.O),v,x.d[v])},
$C:"$0",
$R:0,
$S:z+1}
R.cuO.prototype={
$0:function(){H.dI("design.1")
return R.d8R()},
$C:"$0",
$R:0,
$S:z+2}
R.cuP.prototype={
$0:function(){H.dI("design.1")
return E.d8T()},
$C:"$0",
$R:0,
$S:z+3}
R.cuS.prototype={
$2:function(d,e){return J.pj(J.d(d,"pos"),J.d(e,"pos"))},
$S:117}
R.cuR.prototype={
$1:function(d){return V.bS(new R.cuQ(this.a,this.b),!1,null,y.z)},
$S:184}
R.cuQ.prototype={
$1:function(d){var x,w=null,v=this.a
if(v.d!=null){x=v.c
x.toString
x=!Y.w(x,!1,y.k).c}else x=!1
if(x){x=this.b
x=v.bdm(x.a,x.b)
v=x}else v=M.r(w,C.xk,C.c,K.j(d).rx,w,w,w,w,w,w,w,w,w,w)
return v},
$S:13};(function aliases(){var x=L.af4.prototype
x.b_v=x.m})();(function installTearOffs(){var x=a._static_0
x(R,"aYa","dtJ",4)})();(function inheritance(){var x=a.mixin,w=a.inheritMany,v=a.inherit
w(N.J,[L.Cd,R.ZK])
w(N.K,[L.af4,R.aSW])
v(L.aC7,L.af4)
w(H.fQ,[L.bHu,R.cuL,R.cuM,R.cuN,R.cuO,R.cuP,R.cuS,R.cuR,R.cuQ])
x(L.af4,U.cj)})()
H.ew(b.typeUniverse,JSON.parse('{"Cd":{"J":[],"h":[]},"aC7":{"K":["Cd"]},"ZK":{"J":[],"h":[]},"aSW":{"K":["ZK"]}}'))
0
var y=(function rtii(){var x=H.a9
return{k:x("ng"),t:x("E<a_<t,@>>"),h:x("E<il>"),s:x("E<t>"),P:x("a_<t,@>"),w:x("hQ"),v:x("zn"),a:x("ao"),S:x("zI"),N:x("t"),D:x("Ao"),O:x("b2<t>"),z:x("@"),H:x("~")}})();(function constants(){C.ajp=new R.ZK(null)
C.dFB=new D.mb("ScreenValue.data")
C.dFC=new D.mb("ScreenValue.set_config")
C.dFD=new D.mb("ScreenValue.splashscreen")
C.dFE=new D.mb("ScreenValue.product")
C.dFF=new D.mb("ScreenValue.order")
C.dFG=new D.mb("ScreenValue.screens")
C.dFH=new D.mb("ScreenValue.build")
C.dFI=new D.mb("ScreenValue.release")})()}
$__dart_deferred_initializers__["lZt8t8PvO6vz1O/9aPSTRrAX714="] = $__dart_deferred_initializers__.current
//# sourceMappingURL=main.dart.js_7.part.js.map
